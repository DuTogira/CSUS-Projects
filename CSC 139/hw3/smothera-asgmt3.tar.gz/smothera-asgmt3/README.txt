To run the associated program:
1) execute "gcc -o proj3 smothera-asgmt3.c buffer.h -lpthread -lrt -std=c99" from 
   the directory where this readme is located.
2) Execute proj3 with the desired settings
   based on the format: 
   "./proj3 [SleepDuration] [NumProducers] [NumConsumers]"
   EG: "./proj3 20 5 1"
3) Enjoy
