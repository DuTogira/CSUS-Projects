To run the associated program:
1) execute "gcc -o proj4 smothera-asgmt4.c -std=c99" from the directory
   where this readme is located.
2) execute proj4 with the desired input file and scheduler name 
   based on the format:
   "./proj4 [input.file] [FIFO|LRU|OPT]"
   EG: "./proj4 input1.txt FIFO"
3) Enjoy